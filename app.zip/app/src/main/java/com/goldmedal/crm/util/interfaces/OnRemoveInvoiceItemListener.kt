package com.goldmedal.crm.util.interfaces

import java.text.FieldPosition

interface OnRemoveInvoiceItemListener {

    fun onRemoveClick(slNo: Int,position: Int)
}