package com.goldmedal.crm.ui.auth

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.goldmedal.crm.R
import com.goldmedal.crm.data.model.SessionData
import com.goldmedal.crm.databinding.ActivityLoginBinding
import com.goldmedal.crm.databinding.ActivityUserProfileBinding
import com.goldmedal.crm.ui.dashboard.DashboardActivity
import com.goldmedal.crm.util.formatDateString
import com.goldmedal.crm.util.generateRandomCaptcha
import com.goldmedal.crm.util.getDeviceId
import com.goldmedal.crm.util.snackbar
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import kotlinx.android.synthetic.main.activity_login.*
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

//<!--added by shetty 6 jan 21-->
class UserProfileActivity : AppCompatActivity(), KodeinAware {

    override val kodein by kodein()
    private val factory: LoginViewModelFactory by instance()
    private lateinit var viewModel: LoginViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val binding: ActivityUserProfileBinding = DataBindingUtil.setContentView(this, R.layout.activity_user_profile)

        viewModel = ViewModelProvider(this, factory).get(LoginViewModel::class.java)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)

        viewModel.getLoggedInUser().observe(this, Observer { user ->

            if (user != null) {
                binding.tvUserName.text = user.UserName
                binding.tvEmployeeCode.text = user.EmpCode
                binding.tvJoiningDate.text = formatDateString(user.JoiningDate ?: "", "MM/dd/yyyy hh:mm:ss a", "dd/MM/yyyy")
                binding.tvUserMobNo.text = user.UserPhone
                binding.tvOfficeEmail.text = user.UserEmail
                binding.tvUserServiceCentre.text = user.ServiceCenter
                binding.tvScAddress.text = user.ScAddress
                binding.tvUserWorkExp.text = "Experience : "+user.WorkExp
                binding.tvHighestQualification.text = user.HighestQualification
                binding.tvHomeAddress.text = user.Address + ", " + user.AreaName + ", " + user.CityName + ", " + user.StateName + ", " + user.CountryName + ", " + user.Pincode
            }
        })

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    companion object {
        fun start(context: Context) {
            context.startActivity(Intent(context, UserProfileActivity::class.java))
        }
    }
}
