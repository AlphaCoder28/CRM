package com.goldmedal.crm.data.model

data class SessionData(
    val LogNo: Int,
    val SessionId: String
)