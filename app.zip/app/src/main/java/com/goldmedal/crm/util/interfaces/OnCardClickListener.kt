package com.goldmedal.crm.util.interfaces

import java.text.FieldPosition

interface OnCardClickListener {

    fun onCardClick(position: Int, ticketId: Int)
}