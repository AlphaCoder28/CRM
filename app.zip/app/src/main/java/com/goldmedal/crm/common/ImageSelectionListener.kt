package com.goldmedal.crm.common

interface ImageSelectionListener {
    fun choosePhotoFromGallery()
    fun takePhotoFromCamera()
}