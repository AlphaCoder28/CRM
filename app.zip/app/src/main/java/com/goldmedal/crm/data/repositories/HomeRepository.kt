package com.goldmedal.crm.data.repositories

import android.location.Location
import com.goldmedal.crm.data.db.AppDatabase
import com.goldmedal.crm.data.model.AddedInvoiceItemData
import com.goldmedal.crm.data.network.MyApi
import com.goldmedal.crm.data.network.SafeApiRequest
import com.goldmedal.crm.data.network.responses.*
import org.json.JSONArray
import retrofit2.http.Field

class HomeRepository(
    private val api: MyApi,
    private val db: AppDatabase
) : SafeApiRequest() {

    /*  - - - - - - - - - - - - -   Active User - - - - - - - - - - - -  */
    fun getLoggedInUser() = db.getUserDao().getUser()

    suspend fun getDashboardData(userID: Int): DashboardResponse {
        return apiRequest { api.dashboardDetail(userID) }
    }

    /*  - - - - - - - - - - - - -   ALL ASSIGNED TICKETS - - - - - - - - - - - -  */

    suspend fun getAllAssignedTickets(userId: Int): GetAssignedTicketResponse {
        return apiRequest {
            api.getAllAssignedTickets(userId)
        }
    }


    /*  - - - - - - - - - - - - -  TICKET COUNT FOR SERVICE ENGINEER - - - - - - - - - - - -  */

    suspend fun getTicketsCount(
        userId: Int,
        fromDate: String,
        toDate: String
    ): GetTicketsCountResponse {
        return apiRequest {
            api.getTicketsCount(userId, fromDate, toDate)
        }
    }
    /*  - - - - - - - - - - - - -  TODAY APPOINTMENT FOR SERVICE ENGINEER - - - - - - - - - - - -  */

    suspend fun getAppointments(
        userId: Int,
        fromDate: String,
        toDate: String
    ): GetAppointmentsResponse {
        return apiRequest {
            api.getAppointments(userId, fromDate, toDate)
        }
    }

    /*  - - - - - - - - - - - - -   ACCEPT TICKET - - - - - - - - - - - -  */

    suspend fun acceptTicket(
        userId: Int,
        ticketNo: Int,
        latitude: String,
        longitude: String,
        location: String
    ): AcceptRejectResponse {
        return apiRequest {
            api.acceptTicket(userId, ticketNo, latitude, longitude, location)
        }
    }

    /*  - - - - - - - - - - - - -   CONTACTS - - - - - - - - - - - -  */

    suspend fun getCustomerContacts(userId: Int, searchBy: String): CustomerContactsResponse {
        return apiRequest {
            api.getCustomerContacts(userId, searchBy)
        }
    }

    /*  - - - - - - - - - - - - -   GET TICKET DETAILS- - - - - - - - - - - -  */

    suspend fun getTicketDetails(userID: Int, ticketId: Int): GetTicketDetailsResponse {
        return apiRequest { api.getTicketDetails(userID, ticketID = ticketId) }
    }


    /*  - - - - - - - - - - - - -   SERVICE TICKET DETAILS- - - - - - - - - - - -  */
    suspend fun getTicketDetailsForEngineer(
        userID: Int,
        fromDate: String,
        toDate: String,
        type: Int,
        searchBy: String
    ): GetTicketDetailsForEngineerResponse {
        return apiRequest {
            api.getTicketDetailsForEngineer(
                userID,
                fromDate,
                toDate,
                type,
                searchBy
            )
        }
    }


    /*  - - - - - - - - - - - - -   GET ITEM AND PART DETAILS- - - - - - - - - - - -  */

    suspend fun getItemAndPartDetails(itemSlNo: Int, searchBy: String): UsedItemAndPartResponse {
        return apiRequest { api.getItemAndPartDetails(itemSlNo, searchBy) }
    }


    /*  - - - - - - - - - - - - -   GET PART AND ITEM DETAILS- - - - - - - - - - - -  */

    suspend fun getPartAndItemDetails(partSlNo: Int, searchBy: String): UsedPartAndItemResponse {
        return apiRequest { api.getPartAndItemDetails(partSlNo, searchBy) }
    }

    /*  - - - - - - - - - - - - -   GET INVOICE ITEM DETAIL - - - - - - - - - - - -  */

    suspend fun getInvoiceItemDetails(searchBy: String): GetItemForInvoiceResponse {
        return apiRequest { api.getInvoiceItemDetail(searchBy) }
    }


    /*  - - - - - - - - - - - - -   GET INVOICE HISTORY DETAIL - - - - - - - - - - - -  */

    suspend fun getInvoiceHistoryDetails(userID: Int): GetInvoiceListResponse {
        return apiRequest { api.getInvoiceList(userID) }
    }


    /*  - - - - - - - - - - - - -   GENERATE INVOICE FOR ITEMS - - - - - - - - - - - -  */

    suspend fun generateInvoiceForItems(
        slNo: Int,
        custId: Int,
        tktId: Int,
        status: String,
        taxType: Int,
        taxAmount1: Double,
        taxAmount2: Double,
        preTaxAmount: Double,
        discount: Double,
        afterDiscountAmount: Double,
        finalTotal: Double,
        userID: Int,
        logNo: Int,
        applicationID: Int,
        invoiceItemDetail: JSONArray
    ): UpdateVisitStatusResponse {
        return apiRequest {
            api.generateInvoiceForItems(
                slNo,
                custId,
                tktId,
                status,
                taxType,
                taxAmount1,
                taxAmount2,
                preTaxAmount,
                discount,
                afterDiscountAmount,
                finalTotal,
                userID,
                logNo,
                applicationID,
                invoiceItemDetail
            )
        }
    }

}