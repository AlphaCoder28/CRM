package com.goldmedal.crm.data.model

data class SymptomsData(
    val Slno: Int,
    val SymptomsName: String
)