package com.goldmedal.crm.common;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
