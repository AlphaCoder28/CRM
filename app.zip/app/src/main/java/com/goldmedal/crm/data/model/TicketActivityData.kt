package com.goldmedal.crm.data.model

data class TicketActivityData(
    val Activity: String,
    val ActivityDateTime: String,
    val TimeDifference: String
)