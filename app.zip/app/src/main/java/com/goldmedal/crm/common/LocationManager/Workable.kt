package com.goldmedal.crm.common.LocationManager

/**
 * * Created by alejandro.tkachuk
 */
interface Workable<T>  {
    fun work(t: T)
}