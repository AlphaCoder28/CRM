package com.goldmedal.crm.data.model

data class AcceptRejectTicket(
    val StatusCode: Int? = null,
    val StatusMessage: String? = null
)