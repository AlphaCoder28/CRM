package com.goldmedal.crm.common

data class HexColors(var colorCode: String) {


}