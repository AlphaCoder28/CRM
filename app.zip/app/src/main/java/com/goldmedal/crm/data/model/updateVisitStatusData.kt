package com.goldmedal.crm.data.model

data class UpdateVisitStatusData(
//    val Out: Int? = null
    val ActionStatus: Int? = null,
    val ActionIDStatus: Int? = null
)