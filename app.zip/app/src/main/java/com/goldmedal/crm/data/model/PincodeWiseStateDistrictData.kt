package com.goldmedal.crm.data.model

data class PincodeWiseStateDistrictData(
    val DistrictID: Int,
    val DistrictName: String,
    val StateID: Int,
    val StateName: String
)