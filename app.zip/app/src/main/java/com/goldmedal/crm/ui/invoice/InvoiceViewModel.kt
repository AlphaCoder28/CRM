package com.goldmedal.crm.ui.invoice


import androidx.lifecycle.ViewModel
import com.goldmedal.crm.common.ApiStageListener
import com.goldmedal.crm.common.DashboardApiListener
import com.goldmedal.crm.data.model.AddedInvoiceItemData
import com.goldmedal.crm.data.repositories.HomeRepository
import com.goldmedal.crm.util.ApiException
import com.goldmedal.crm.util.Coroutines
import com.goldmedal.crm.util.NoInternetException
import org.json.JSONArray
import java.net.SocketTimeoutException


class InvoiceViewModel(
        private val repository: HomeRepository
) : ViewModel() {

    fun getLoggedInUser() = repository.getLoggedInUser()

    var apiListener: ApiStageListener<Any>? = null

    fun getInvoiceItemDetail(searchBy: String) {

            var strSearchBy = searchBy

            if (strSearchBy.isEmpty()) {
                strSearchBy = "-"
            }

            apiListener?.onStarted("invoice_item")

            Coroutines.main {
                try {
                    val invoiceItemResponse = repository.getInvoiceItemDetails(strSearchBy)

                    if (!invoiceItemResponse.getItemForInvoice?.isNullOrEmpty()!!) {
                        invoiceItemResponse.getItemForInvoice.let {
                            apiListener?.onSuccess(it, "invoice_item")
                            return@main
                        }
                    }else {

                        val errorResponse = invoiceItemResponse?.Errors
                        if (!errorResponse?.isNullOrEmpty()!!) {
                            errorResponse[0]?.ErrorMsg?.let {
                                apiListener?.onError(it, "invoice_item", false)
                            }
                        }
                    }



                }catch (e: ApiException) {
                    apiListener?.onError(e.message!!, "invoice_item", true)
                } catch (e: NoInternetException) {

                    print("Internet not available")
                    apiListener?.onError(e.message!!, "invoice_item", true)


                }catch (e: SocketTimeoutException) {
                    apiListener?.onError(e.message!!, "invoice_item", true)


                }
            }

        }


    fun generateInvoiceForItems(slNo: Int,
                                custId: Int,
                                tktId: Int,
                                status: String,
                                taxType: Int,
                                taxAmount1: Double,
                                taxAmount2: Double,
                                preTaxAmount: Double,
                                discount: Double,
                                afterDiscountAmount: Double,
                                finalTotal: Double,
                                userID: Int,
                                logNo: Int,
                                applicationID: Int,
                                invoiceItemDetail: JSONArray) {

        apiListener?.onStarted("invoice_generate")

        Coroutines.main {
            try {
                val invoiceGenerateResponse = repository.generateInvoiceForItems(slNo,
                    custId,
                    tktId,
                    status,
                    taxType,
                    taxAmount1,
                    taxAmount2,
                    preTaxAmount,
                    discount,
                    afterDiscountAmount,
                    finalTotal,
                    userID,
                    logNo,
                    applicationID,
                    invoiceItemDetail)

                if (!invoiceGenerateResponse.updateStatus?.isNullOrEmpty()!!) {
                    invoiceGenerateResponse.updateStatus.let {
                        apiListener?.onSuccess(it, "invoice_generate")
                        return@main
                    }
                }else {

                    val errorResponse = invoiceGenerateResponse?.Errors
                    if (!errorResponse?.isNullOrEmpty()!!) {
                        errorResponse[0]?.ErrorMsg?.let {
                            apiListener?.onError(it, "invoice_generate", false)
                        }
                    }
                }



            }catch (e: ApiException) {
                apiListener?.onError(e.message!!, "invoice_generate", true)
            } catch (e: NoInternetException) {

                print("Internet not available")
                apiListener?.onError(e.message!!, "invoice_generate", true)


            }catch (e: SocketTimeoutException) {
                apiListener?.onError(e.message!!, "invoice_generate", true)


            }
        }

    }



    fun getInvoiceListDetail(userid: Int) {

        apiListener?.onStarted("invoice_history")

        Coroutines.main {
            try {
                val invoiceListResponse = repository.getInvoiceHistoryDetails(userid)

                if (!invoiceListResponse.getInvoiceList?.isNullOrEmpty()!!) {
                    invoiceListResponse.getInvoiceList.let {
                        apiListener?.onSuccess(it, "invoice_history")
                        return@main
                    }
                }else {

                    val errorResponse = invoiceListResponse?.Errors
                    if (!errorResponse?.isNullOrEmpty()!!) {
                        errorResponse[0]?.ErrorMsg?.let {
                            apiListener?.onError(it, "invoice_history", false)
                        }
                    }
                }



            }catch (e: ApiException) {
                apiListener?.onError(e.message!!, "invoice_history", true)
            } catch (e: NoInternetException) {

                print("Internet not available")
                apiListener?.onError(e.message!!, "invoice_history", true)


            }catch (e: SocketTimeoutException) {
                apiListener?.onError(e.message!!, "invoice_history", true)


            }
        }

    }



}
