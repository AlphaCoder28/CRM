package com.goldmedal.crm.data.model

data class GetTimeSlots(
    val TimeSlot: String,
    val TimeSlotID: Int
)