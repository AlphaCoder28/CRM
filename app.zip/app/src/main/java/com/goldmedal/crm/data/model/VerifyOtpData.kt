package com.goldmedal.crm.data.model

data class VerifyOtpData(
        val MobileNo: String? = null
        , val StatusCode: String? = null
        , val StatusMessage: String? = null
)