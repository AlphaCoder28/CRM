package com.goldmedal.crm.data.model

data class UsedPartAndItemData(
        val PartSlno: Int,
        val PartName: String,
        val Item: String
)