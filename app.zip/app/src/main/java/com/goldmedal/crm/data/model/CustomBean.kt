package com.goldmedal.crm.data.model

class CustomBean {

    var imageRes: Int = 0

    var imageDescription: String? = null

    var backgroundRes: Int = 0
}