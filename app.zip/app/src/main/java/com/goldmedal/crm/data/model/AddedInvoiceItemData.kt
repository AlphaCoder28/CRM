package com.goldmedal.crm.data.model

data class AddedInvoiceItemData( val itemName: String,
                                 val Slno: Int,
                                 val ItemID: Int,
                                 val Quantity: Int,
                                 val PricePerUnit: Double,
                                 val DiscountPercent: Double,
                                 val DiscountAmount: Double,
                                 val AfterDiscountAmount: Double,
                                 val TaxType: Int,
                                 val TaxAmount1: Double,
                                 val TaxAmount2: Double,
                                 val TaxPercent1: Double,
                                 val TaxPercent2: Double,
                                 val PreTaxAmount: Double,
                                 val FinalPrice: Double)
