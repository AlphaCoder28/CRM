package com.goldmedal.crm.data.model

data class ContactsData(
    val CustAddress: String,
    val CustContactNo: String,
    val CustName: String,
    val CustomerID: Int
)