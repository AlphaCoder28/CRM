package com.goldmedal.crm.data.model

data class closedOtpData(
    val GoodOtp: String?,
    val BadOTP: String?
)
