package com.goldmedal.crm.data.model

data class NotificationFeedsData(
        val Title: String? = null,
        val Body: String? = null,
        val CreateDate: String? = null,
        val ExpiryDate: String? = null,
        val Duration: String? = null,
        val NotificationId: String? = null

)