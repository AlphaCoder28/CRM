package com.goldmedal.crm.data.model

data class UsedItemAndPartData (
        val ItemSlno: Int,
        val ItemName: String,
        val Part: String
)
