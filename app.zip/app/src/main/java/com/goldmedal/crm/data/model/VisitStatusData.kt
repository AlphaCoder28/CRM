package com.goldmedal.crm.data.model


data class VisitStatusData(
    val VisitStatus: String? = null
    , val ActionId: Int? = null
)