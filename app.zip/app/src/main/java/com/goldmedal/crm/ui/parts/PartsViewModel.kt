package com.goldmedal.crm.ui.parts


import androidx.lifecycle.ViewModel
import com.goldmedal.crm.common.ApiStageListener
import com.goldmedal.crm.common.DashboardApiListener
import com.goldmedal.crm.data.repositories.HomeRepository
import com.goldmedal.crm.util.ApiException
import com.goldmedal.crm.util.Coroutines
import com.goldmedal.crm.util.NoInternetException
import java.net.SocketTimeoutException


class PartsViewModel(
        private val repository: HomeRepository
) : ViewModel() {

    fun getLoggedInUser() = repository.getLoggedInUser()

    var apiListener: ApiStageListener<Any>? = null

    fun getItemAndPartDetail(itemSlNo: Int,searchBy: String) {

        var strSearchBy = searchBy

        if (strSearchBy.isEmpty()) {
            strSearchBy = "-"
        }

        apiListener?.onStarted("itemAndPartDetail")

        Coroutines.main {
            try {
                val itemAndPartResponse = repository.getItemAndPartDetails(itemSlNo,strSearchBy)

                if (!itemAndPartResponse.itemAndPartData?.isNullOrEmpty()!!) {
                    itemAndPartResponse.itemAndPartData.let {
                        apiListener?.onSuccess(it, "itemAndPartDetail")
                        return@main
                    }
                }else {

                    val errorResponse = itemAndPartResponse?.Errors
                    if (!errorResponse?.isNullOrEmpty()!!) {
                        errorResponse[0]?.ErrorMsg?.let {
                            apiListener?.onError(it, "itemAndPartDetail", false)
                        }
                    }
                }



            }catch (e: ApiException) {
                apiListener?.onError(e.message!!, "itemAndPartDetail", true)
            } catch (e: NoInternetException) {

                print("Internet not available")
                apiListener?.onError(e.message!!, "itemAndPartDetail", true)


            }catch (e: SocketTimeoutException) {
                apiListener?.onError(e.message!!, "itemAndPartDetail", true)


            }
        }

    }


    fun getPartAndItemDetail(partSlNo: Int,searchBy: String) {

        var strSearchBy = searchBy

        if (strSearchBy.isEmpty()) {
            strSearchBy = "-"
        }

        apiListener?.onStarted("partAndItemDetail")

        Coroutines.main {
            try {
                val partAndItemResponse = repository.getPartAndItemDetails(partSlNo,strSearchBy)

                if (!partAndItemResponse.partAndItemData?.isNullOrEmpty()!!) {
                    partAndItemResponse.partAndItemData.let {
                        apiListener?.onSuccess(it, "partAndItemDetail")
                        return@main
                    }
                }else {

                    val errorResponse = partAndItemResponse?.Errors
                    if (!errorResponse?.isNullOrEmpty()!!) {
                        errorResponse[0]?.ErrorMsg?.let {
                            apiListener?.onError(it, "partAndItemDetail", false)
                        }
                    }
                }



            }catch (e: ApiException) {
                apiListener?.onError(e.message!!, "partAndItemDetail", true)
            } catch (e: NoInternetException) {

                print("Internet not available")
                apiListener?.onError(e.message!!, "partAndItemDetail", true)


            }catch (e: SocketTimeoutException) {
                apiListener?.onError(e.message!!, "partAndItemDetail", true)


            }
        }

    }

}
