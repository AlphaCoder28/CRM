package com.goldmedal.crm.data.model

data class GetOtpData(
    val MobileNo: String,
    val StatusCode: Int,
    val StatusMessage: String
)